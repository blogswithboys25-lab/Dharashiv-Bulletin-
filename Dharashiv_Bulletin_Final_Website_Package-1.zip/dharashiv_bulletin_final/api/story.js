// Vercel Serverless Function: /api/story?id=BLOGGER_POST_ID
// Fetches the public Blogger feed and returns server-rendered Open Graph metadata.
const BLOG_FEED = "https://news.dharashivbulletin.in/feeds/posts/default?alt=json&max-results=100";
const SITE = "https://www.dharashivbulletin.in";

function esc(s = "") {
  return String(s).replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[c]));
}
function plain(htmlText = "") {
  return String(htmlText).replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&").replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"').replace(/\s+/g, " ").trim();
}
function postId(entry) {
  const raw = entry?.id?.$t || "";
  return raw.split("post-")[1] || raw;
}
function postImage(entry) {
  if (entry?.media$thumbnail?.url) {
    return entry.media$thumbnail.url.replace(/\/s[0-9]+(-c)?\//, "/s1200/");
  }
  const body = entry?.content?.$t || entry?.summary?.$t || "";
  const m = body.match(/<img[^>]+src=["']([^"']+)["']/i);
  return m ? m[1] : `${SITE}/assets/db-news-logo.jpg`;
}
module.exports = async (req, res) => {
  const id = String(req.query.id || "").replace(/[^0-9]/g, "");
  if (!id) return res.status(400).send("बातमी क्रमांक उपलब्ध नाही.");
  try {
    const response = await fetch(BLOG_FEED, { headers: { "User-Agent": "DharashivBulletin/1.0" } });
    if (!response.ok) throw new Error("Blogger feed unavailable");
    const feed = await response.json();
    const entries = feed?.feed?.entry || [];
    const entry = entries.find(item => postId(item) === id);
    if (!entry) return res.status(404).send("ही बातमी सापडली नाही.");
    const title = entry.title?.$t || "धाराशिव बुलेटिन";
    const body = entry.content?.$t || entry.summary?.$t || "";
    const description = plain(body).slice(0, 220) || "धाराशिव बुलेटिन - विश्वसनीय मराठी बातम्या.";
    const image = postImage(entry);
    const url = `${SITE}/story/${id}`;
    const articleUrl = `${SITE}/?id=${id}`;
    const date = entry.published?.$t || "";
    res.setHeader("Cache-Control", "s-maxage=300, stale-while-revalidate=600");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    return res.status(200).send(`<!doctype html>
<html lang="mr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)} | धाराशिव बुलेटिन</title>
<meta name="description" content="${esc(description)}">
<meta name="robots" content="index,follow,max-image-preview:large">
<link rel="canonical" href="${esc(url)}">
<meta property="og:type" content="article">
<meta property="og:site_name" content="धाराशिव बुलेटिन">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(description)}">
<meta property="og:url" content="${esc(url)}">
<meta property="og:image" content="${esc(image)}">
<meta property="og:image:alt" content="${esc(title)}">
<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
<meta property="article:published_time" content="${esc(date)}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(title)}">
<meta name="twitter:description" content="${esc(description)}">
<meta name="twitter:image" content="${esc(image)}">
<script type="application/ld+json">${JSON.stringify({
  "@context":"https://schema.org", "@type":"NewsArticle", headline:title,
  description, image:[image], datePublished:date, mainEntityOfPage:url,
  publisher:{"@type":"Organization",name:"धाराशिव बुलेटिन",logo:{"@type":"ImageObject",url:`${SITE}/assets/db-news-logo.jpg`}}
}).replace(/</g,"\\u003c")}</script>
<style>
body{font-family:Arial,sans-serif;margin:0;background:#f5f6f8;color:#222}
main{max-width:760px;margin:35px auto;background:white;padding:24px;border-radius:12px}
img{width:100%;max-height:440px;object-fit:contain;background:#f1f1f1}
h1{color:#c62828;line-height:1.5}p{line-height:1.8}
a{display:inline-block;background:#c62828;color:white;padding:12px 18px;border-radius:7px;text-decoration:none}
small{color:#777}
</style></head><body><main>
<img src="${esc(image)}" alt="${esc(title)}"><h1>${esc(title)}</h1>
<p>${esc(description)}</p><small>धाराशिव बुलेटिन | स्पंदन जनतेचे</small><p><a href="${esc(articleUrl)}">संपूर्ण बातमी वाचा</a></p>
</main><script>setTimeout(function(){location.replace(${JSON.stringify(articleUrl)});},1200);</script>
</body></html>`);
  } catch (e) {
    res.setHeader("Cache-Control", "no-store");
    return res.status(502).send("बातमीचा Preview सध्या उपलब्ध नाही. कृपया थोड्या वेळाने प्रयत्न करा.");
  }
};
