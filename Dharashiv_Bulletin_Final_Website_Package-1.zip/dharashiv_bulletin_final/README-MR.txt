धाराशिव बुलेटिन — अंतिम वेबसाइट पॅकेज

या ZIP मध्ये:
- index.html : मुख्य वेबसाइट (Blogger feed कायम)
- api/story.js : प्रत्येक बातमीसाठी server-rendered Open Graph / Twitter preview
- vercel.json : /story/ID URL ला API कडे route
- assets/db-news-logo.jpg : दिलेला DB NEWS लोगो
- About, Contact, Privacy Policy, Disclaimer, Terms, Grievance पृष्ठे
- ads.txt, robots.txt, sitemap.xml

महत्त्वाच्या सूचना:
1) GitHub repository च्या root मध्ये या ZIP मधील फाइल्स upload करा. आधी backup घ्या.
2) Vercel मध्ये Framework Preset = Other आणि Root Directory योग्य असल्याची खात्री करा.
3) वेबसाइटचे root index.html lowercase असणे आवश्यक आहे. जुन्या Index.html फाइलला लगेच delete करू नका; deploy आधी duplicate/route तपासा.
4) Contact, Privacy आणि Grievance पृष्ठांमध्ये 'येथे अधिकृत ई-मेल पत्ता टाका' आणि कार्यालयाचा पत्ता भरूनच live करा.
5) ads.txt मधील Publisher ID सध्याच्या HTML मधील ca-pub-6115119511519503 वरून घेतला आहे. तुमच्या AdSense खात्यातील ID हाच आहे याची खात्री करा.
6) हा कोड AdSense साठी आवश्यक मूलभूत पारदर्शकता/नेव्हिगेशन तयार करतो; Google मंजुरीची हमी देत नाही. बातम्यांमध्ये स्वतःचे मूळ रिपोर्टिंग, स्रोत पडताळणी, कॉपीराइट परवानगी आणि पुरेसा उपयुक्त मजकूर आवश्यक आहे.
7) सोशल preview साठी /story/ID वापरा. पहिल्या deploy नंतर Facebook Sharing Debugger आणि WhatsApp वर तपासा. Blogger feed सार्वजनिक आणि उपलब्ध असणे आवश्यक.
8) हा पॅकेज Vercel/GitHub वर आपोआप publish केलेला नाही. तुमची स्पष्ट परवानगी नसताना live बदल केलेले नाहीत.
